-- MySQL dump 10.13  Distrib 5.5.50, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: blog
-- ------------------------------------------------------
-- Server version	5.5.50-0ubuntu0.14.04.1
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `blogs`
--

DROP TABLE IF EXISTS `blogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blogs` (
  `id` varchar(50) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `user_image` varchar(500) NOT NULL,
  `name` varchar(50) NOT NULL,
  `summary` varchar(200) NOT NULL,
  `content` mediumtext NOT NULL,
  `created_at` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_created_at` (`created_at`)
);
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blogs`
--

INSERT INTO `blogs` VALUES ('00146930663391356aac6631a8343d9992a0fb3f93d8269000','001469306312239602acabaf4ca489ca61bb0038844cee8000','Jacky','http://www.gravatar.com/avatar/eafa1f42f50810c6b5f2cfc3b78a9991?d=mm&s=120','What is Python','Python is a widely used high-level, general-purpose, interpreted, dynamic programming language.','Python is an interpreted, object-oriented, high-level programming language with dynamic semantics. Its high-level built in data structures, combined with dynamic typing and dynamic binding, make it very attractive for Rapid Application Development, as well as for use as a scripting or glue language to connect existing components together. Python\'s simple, easy to learn syntax emphasizes readability and therefore reduces the cost of program maintenance. Python supports modules and packages, which encourages program modularity and code reuse. The Python interpreter and the extensive standard library are available in source or binary form without charge for all major platforms, and can be freely distributed.\n\nOften, programmers fall in love with Python because of the increased productivity it provides. Since there is no compilation step, the edit-test-debug cycle is incredibly fast. Debugging Python programs is easy: a bug or bad input will never cause a segmentation fault. Instead, when the interpreter discovers an error, it raises an exception. When the program doesn\'t catch the exception, the interpreter prints a stack trace. A source level debugger allows inspection of local and global variables, evaluation of arbitrary expressions, setting breakpoints, stepping through the code a line at a time, and so on. The debugger is written in Python itself, testifying to Python\'s introspective power. On the other hand, often the quickest way to debug a program is to add a few print statements to the source: the fast edit-test-debug cycle makes this simple approach very effective.',1469306633.91332);
INSERT INTO `blogs` VALUES ('0014693292880560abeea3edb28496da6fe5c0eb55b252b000','001469306312239602acabaf4ca489ca61bb0038844cee8000','Jacky','http://www.gravatar.com/avatar/eafa1f42f50810c6b5f2cfc3b78a9991?d=mm&s=120','Model–view–controller (MVC)','Model–view–controller (MVC) is a software architectural pattern for implementing user interfaces on computers.','Although originally developed for desktop computing, model–view–controller has been widely adopted as an architecture for World Wide Web applications in major programming languages. Several commercial and noncommercial web frameworks have been created that enforce the pattern. These software frameworks vary in their interpretations, mainly in the way that the MVC responsibilities are divided between the client and server.\n\nEarly web MVC frameworks took a thin client approach that placed almost the entire model, view and controller logic on the server. This is still reflected in popular frameworks such as Ruby on Rails, Django, ASP.NET MVC and Express. In this approach, the client sends either hyperlink requests or form input to the controller and then receives a complete and updated web page (or other document) from the view; the model exists entirely on the server. As client technologies have matured, frameworks such as AngularJS, EmberJS, JavaScriptMVC and Backbone have been created that allow the MVC components to execute partly on the client (also see Ajax).',1469329288.05653);
INSERT INTO `blogs` VALUES ('0014693294101266736cb5526d34fc384ceb03445322957000','001469306312239602acabaf4ca489ca61bb0038844cee8000','Jacky','http://www.gravatar.com/avatar/eafa1f42f50810c6b5f2cfc3b78a9991?d=mm&s=120','Model–view–viewmodel (MVVM)','Model–view–viewmodel (MVVM) is a software architectural pattern.','##Model\nModel refers either to a domain model, which represents real state content (an object-oriented approach), or to the data access layer, which represents content (a data-centric approach).\n##View\nAs in the MVC and MVP patterns, the view is the user interface (UI).\n##View model\nThe view model is an abstraction of the view exposing public properties and commands. Instead of the controller of the MVC pattern, or the presenter of the MVP pattern, MVVM has a binder. In the view model, the binder mediates communication between the view and the data binder.[clarification needed] The view model has been described as a state of the data in the model.\n##Binder\nDeclarative data- and command-binding are implicit in the MVVM pattern. In the Microsoft solution stack, the binder is a markup language called XAML. The binder frees the developer from being obliged to write boiler-plate logic to synchronize the view model and view. When implemented outside of the Microsoft stack the presence of a declarative databinding technology is a key enabler of the pattern.',1469329410.12696);
INSERT INTO `blogs` VALUES ('00146936313167979a3808700fd451e9219fac8f03a45e9000','001469306312239602acabaf4ca489ca61bb0038844cee8000','Jacky','http://www.gravatar.com/avatar/eafa1f42f50810c6b5f2cfc3b78a9991?d=mm&s=120','JavaScript Tutorial','JavaScript is the programming language of HTML and the Web.','<!DOCTYPE html>\n<html>\n<body>\n\n<h1>My First JavaScript</h1>\n\n<button type=\"button\"\nonclick=\"document.getElementById(\'demo\').innerHTML = Date()\">\nClick me to display Date and Time.</button>\n\n<p id=\"demo\"></p>\n\n</body>\n</html>\n\n```javascript\nvar s = \"JavaScript syntax highlighting\";\nalert(s);\n```',1469363131.67933);

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comments` (
  `id` varchar(50) NOT NULL,
  `blog_id` varchar(50) NOT NULL,
  `user_id` varchar(50) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `user_image` varchar(500) NOT NULL,
  `content` mediumtext NOT NULL,
  `created_at` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_created_at` (`created_at`)
);
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` VALUES ('0014693628592626d9a091f81384118ad124f5a536b5588000','00146930663391356aac6631a8343d9992a0fb3f93d8269000','00146936284194774088b36b7db4c2dbd1cc5663f057f02000','Tom','http://www.gravatar.com/avatar/e4f7cd8905e896b04425b1d08411e9fb?d=mm&s=120','Test comment...',1469362859.26282);

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `passwd` varchar(50) NOT NULL,
  `admin` tinyint(1) NOT NULL,
  `name` varchar(50) NOT NULL,
  `image` varchar(500) NOT NULL,
  `created_at` double NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `idx_email` (`email`),
  KEY `idx_created_at` (`created_at`)
);
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

INSERT INTO `users` VALUES ('001469306312239602acabaf4ca489ca61bb0038844cee8000','jie.jacky.zhang@gmail.com','52f04feda2b62c64993f3da269cfab01b95c4646',1,'Jacky','http://www.gravatar.com/avatar/eafa1f42f50810c6b5f2cfc3b78a9991?d=mm&s=120',1469306312.23923);
INSERT INTO `users` VALUES ('00146936284194774088b36b7db4c2dbd1cc5663f057f02000','tom@example.com','f15346179bc2c37be64ed4ccdca9198652d31613',0,'Tom','http://www.gravatar.com/avatar/e4f7cd8905e896b04425b1d08411e9fb?d=mm&s=120',1469362841.9471);
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-07-24 12:39:54
